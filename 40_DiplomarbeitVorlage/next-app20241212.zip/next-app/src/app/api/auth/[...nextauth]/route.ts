import { handlers } from "@/app/utils/auth"
export const { GET, POST } = handlers

