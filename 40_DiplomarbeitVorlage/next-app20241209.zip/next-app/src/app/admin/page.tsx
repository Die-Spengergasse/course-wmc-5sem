export default function AdminPage() {
    return (
        <div>
            <h1>Admin</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque totam recusandae similique vero quam repellat, provident nemo reprehenderit officia, quod harum ipsum corporis facilis optio, ducimus illo hic sequi culpa.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque totam recusandae similique vero quam repellat, provident nemo reprehenderit officia, quod harum ipsum corporis facilis optio, ducimus illo hic sequi culpa.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque totam recusandae similique vero quam repellat, provident nemo reprehenderit officia, quod harum ipsum corporis facilis optio, ducimus illo hic sequi culpa.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque totam recusandae similique vero quam repellat, provident nemo reprehenderit officia, quod harum ipsum corporis facilis optio, ducimus illo hic sequi culpa.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque totam recusandae similique vero quam repellat, provident nemo reprehenderit officia, quod harum ipsum corporis facilis optio, ducimus illo hic sequi culpa.</p>
        </div>
    );
}    
