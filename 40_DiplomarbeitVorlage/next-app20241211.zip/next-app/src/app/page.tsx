import styles from "./page.module.css";

export default function Home() {
  return (
    <div className={styles.home}>
      <h1>Next.js Musterprojekt für Diplomarbeiten</h1>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officiis esse explicabo tempore saepe maiores quia nihil, quos laboriosam fugit accusamus architecto quas amet! Nostrum, culpa. Pariatur quia error incidunt accusantium.</p>
    </div>
  );
}
