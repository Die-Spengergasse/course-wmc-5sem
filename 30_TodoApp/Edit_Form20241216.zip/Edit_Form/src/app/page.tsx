export default function Home() {
    return (
        <div className="home">
        <h1>Welcome to todo-app</h1>
        <p>
            Dies ist die Datei page.tsx. Sie wird geladen, wenn keine Route angegeben wird.
            Klicke auf einen Punkt im Menü.
        </p>
        </div>
    )
}