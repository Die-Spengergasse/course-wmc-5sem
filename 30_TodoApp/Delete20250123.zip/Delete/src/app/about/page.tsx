export default function AboutPage() {
    return (
        <div className="about">
            <h1>About</h1>
            <p>
                Dies ist ein Frontend für das Todo Backend.
                Es zeigt den Einsatz von Next.js 15 im WMC Unterricht.
            </p>
        </div>
    )
}
